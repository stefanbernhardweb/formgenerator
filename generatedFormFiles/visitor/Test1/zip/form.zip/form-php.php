<?php
            
        
$error = null;
$success = null;
        

if(isset($_POST["submit"])){

	$radiofield3 = filter_var(trim($_POST["radiofield3"]), FILTER_SANITIZE_STRING) ?? null;
	
		$success = "<p class=\"text-success mt-4 text-center\">Das Formular wurde erfolgreich abgesendet!</p>";
}