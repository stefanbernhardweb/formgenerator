<?php 
            require('form-php.php');
        ?>
        <div class='container'>
                            <form method='POST'>  
                                <div class="form-group mt-3">
                                    <label for="radiobuttonfield3" class="form-label">Example</label> <span class="required text-danger"></span>
                                    <div class="form-check">
                        <input class="form-check-input" type="radio" value="exampleOne" name="radiofield3" id="radiofield3" data-id="3">
                        <label class="form-check-label" for="radiofield3">exampleOne</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" value="exampleTwo" name="radiofield3" id="radiofield4" data-id="4">
                        <label class="form-check-label" for="radiofield5">exampleTwo</label>
                    </div>
                                </div>             
                              
                        <div class="form-group mt-3">
                            <input type="submit" class="form-control btn btn-light fw-bold" name="submit" value="Jetzt senden">
                        </div>             
                    </form>
                            <?php echo $error ?? $success; ?>
                        </div>