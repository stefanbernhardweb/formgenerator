<?php 
            require('form-php.php');
        ?>
        <div class='container'>
                            <form method='POST'>  
                                <div class="form-group mt-3">
                                    <label for="textfield2" class="form-label">Text</label> <span class="required text-danger">*</span>
                                    <input type="text" class="form-control" id="textfield2" name="textfield2" placeholder="Example Text" required="required">
                                </div>             
                              
                                <div class="form-group mt-3">
                                    <label for="radiobuttonfield4" class="form-label">Example</label> <span class="required text-danger"></span>
                                    <div class="form-check">
                        <input class="form-check-input" type="radio" value="exampleOne" name="radiofield4" id="radiofield4" data-id="4">
                        <label class="form-check-label" for="radiofield4">exampleOne</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" value="exampleTwo" name="radiofield4" id="radiofield5" data-id="5">
                        <label class="form-check-label" for="radiofield6">exampleTwo</label>
                    </div>
                                <div class="form-check">
                                <input class="form-check-input" type="radio" value="Test" name="radiofield4" id="radiofield6" data-id="6">
                                <label class="form-check-label" for="radiofield6">Test</label>
                            </div></div>             
                              
                                <div class="form-group mt-3">
                                    <label for="passwordfield3" class="form-label">Passwort</label> <span class="required text-danger">*</span>
                                    <input type="password" class="form-control" id="passwordfield3" name="passwordfield3" placeholder="Ihr Passwort" required="required">
                                </div>             
                              
                        <div class="form-group mt-3">
                            <input type="submit" class="form-control btn btn-light fw-bold" name="submit" value="Jetzt senden" style="background-color: rgb(0, 0, 0); color: rgb(255, 255, 255);">
                        </div>             
                    </form>
                            <?php echo $error ?? $success; ?>
                        </div>