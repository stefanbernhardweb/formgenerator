<?php 
            require('form-php.php');
        ?>
        <div class='container'>
                            <form method='POST'>  
                                <div class="form-group mt-3">
                                    <label for="emailfield2" class="form-label">E-Mail</label> <span class="required text-danger"></span>
                                    <input type="email" class="form-control" id="emailfield2" name="emailfield2" placeholder="Ihre E-Mail">
                                </div>             
                              
                        <div class="form-group mt-3">
                            <input type="submit" class="form-control btn btn-light fw-bold" name="submit" value="Jetzt senden">
                        </div>             
                    </form>
                            <?php echo $error ?? $success; ?>
                        </div>