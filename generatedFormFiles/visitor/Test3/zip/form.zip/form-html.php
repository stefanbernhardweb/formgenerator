<?php 
            require('form-php.php');
        ?>
        <div class='container'>
                            <form method='POST'>  
                                <div class="form-group mt-3">
                                    <label for="textarea3" class="form-label">Example</label> <span class="required text-danger">*</span>
                                    <textarea name="textarea3" id="textarea3" placeholder="Example..." class="form-control" rows="5" required="required"></textarea>
                                </div>             
                              
                                <div class="form-group mt-3">
                                    <label for="radiobuttonfield4" class="form-label">Example</label> <span class="required text-danger"></span>
                                    <div class="form-check">
                        <input class="form-check-input" type="radio" value="Hallo 1" name="radiofield4" id="radiofield4" data-id="4">
                        <label class="form-check-label" for="radiofield4">Hallo 1</label>
                    </div>
                    
                                </div>             
                              
                                <div class="form-group mt-3">
                                    <label for="textfield2" class="form-label">Text</label> <span class="required text-danger"></span>
                                    <input type="text" class="form-control" id="textfield2" name="textfield2" placeholder="Example Text">
                                </div>             
                              
                        <div class="form-group mt-3">
                            <input type="submit" class="form-control btn btn-light fw-bold" name="submit" value="Jetzt senden">
                        </div>             
                    </form>
                            <?php echo $error ?? $success; ?>
                        </div>