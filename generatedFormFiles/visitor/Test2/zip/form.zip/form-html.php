<?php 
            require('form-php.php');
        ?>
        <div class='container'>
                            <form method='POST'>  
                                <div class="form-group mt-3">
                                    <label for="textfield2" class="form-label">Text</label> <span class="required text-danger"></span>
                                    <input type="text" class="form-control" id="textfield2" name="textfield2" placeholder="Example Text">
                                </div>             
                              
                                <div class="form-group mt-3">
                                    <label for="passwordfield3" class="form-label">Passwort</label> <span class="required text-danger"></span>
                                    <input type="password" class="form-control" id="passwordfield3" name="passwordfield3" placeholder="Ihr Passwort">
                                </div>             
                              
                                <div class="form-group mt-3">
                                    <label for="textfield4" class="form-label">Test 1234</label> <span class="required text-danger">*</span>
                                    <input type="text" class="form-control" id="textfield4" name="textfield4" placeholder="Test 1234" required="required">
                                </div>             
                              
                        <div class="form-group mt-3">
                            <input type="submit" class="form-control btn btn-light fw-bold" name="submit" value="Jetzt senden" style="background-color: rgb(35, 233, 158);">
                        </div>             
                    </form>
                            <?php echo $error ?? $success; ?>
                        </div>